# Python meshcore

Bindings to access your meshcore companion radio nodes in python.
